#include <dirent.h>
#include <unistd.h>
#include <string>
#include <vector>
#include<iostream>

#include "linux_parser.h"

using std::stof;
using std::string;
using std::to_string;
using std::vector;
using std::cout;
// DONE: An example of how to read data from the filesystem
string LinuxParser::OperatingSystem() {
  string line;
 string key;
 string value;
 std::ifstream filestream(kOSPath);
 if (filestream.is_open()) {
  while (std::getline(filestream, line)) {
     std::replace(line.begin(), line.end(), ' ', '_');
    std::replace(line.begin(), line.end(), '=', ' ');
     std::replace(line.begin(), line.end(), '"', ' ');
     std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
return value;
}

// DONE: An example of how to read data from the filesystem
string LinuxParser::Kernel() {
  string os, kernel,version;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >>version >> kernel;
  }
  return kernel;
}

// BONUS: Update this to use std::filesystem
vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}

// TODO: Read and return the system memory utilization
float LinuxParser::MemoryUtilization() {
  string line;
  float total_mem,free_mem,pecent_mem;
 std::ifstream stream(kProcDirectory + kMeminfoFilename);
 if (stream.is_open()){
   while (getline(stream,line)){
     std::replace(line.begin(),line.end(),':',' ');
     std::istringstream linestream(line);
     string Mem;
     double value;
     linestream>>Mem>>value;
      if (Mem=="MemTotal"){
        total_mem= value ;
      }
       if (Mem=="MemFree"){
         free_mem=value;
         break;
       }
    }
  }

  pecent_mem=((total_mem-free_mem)/total_mem)*100;
  return pecent_mem;  
    
}


 
   

// TODO: Read and return the system uptime
long LinuxParser::UpTime() { 
  float uptime_sec;
  string line;
  std::ifstream stream(kProcDirectory +kUptimeFilename);
  if (stream.is_open()){
    while(getline(stream,line)){
      std::istringstream linestream(line);
      linestream>>uptime_sec;
      return uptime_sec;
    }
 }return uptime_sec;
}
// TODO: Read and return the number of jiffies for the system
long LinuxParser::Jiffies() { 
  string line ;
  long total_jiffy=0;
  vector<long> a{};
  std::ifstream stream(kProcDirectory + kStatFilename);
  if(stream.is_open()){
   getline(stream,line);
    string jiffy_char;
    std::istringstream linestream(line);  
    linestream>>jiffy_char;
    while(linestream>>jiffy_char){
      long value;
      std::istringstream(jiffy_char)>>value;
      a.push_back(value);
    }
  }
    for (long temp_jiffy:a){
      total_jiffy+=temp_jiffy;
    }
  
  return total_jiffy;
 }

 

// TODO: Read and return the number of active jiffies for a PID
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::ActiveJiffies(int pid,int k){
  std::string line;
  int j=1;
  long the_jiffy;
  std::ifstream stream(kProcDirectory + "/"+to_string(pid)+kStatFilename);
  if(stream.is_open()){
   while(getline(stream,line)){
     
     
     long value;
     std::istringstream linestream(line);
     while(linestream>>value){
       if (j==k){
         the_jiffy=value;
         return the_jiffy;
       }
       j+=1;
       }
   
     }
   }return the_jiffy;
}

// TODO: Read and return the number of active jiffies for the system
long LinuxParser::ActiveJiffies() {   
 string line ;
  long total_jiffy=0;
  vector<long> a{};
  long active_jiffy;
  std::ifstream stream(kProcDirectory + kStatFilename);
  if(stream.is_open()){
   getline(stream,line);
    string jiffy_char;
    std::istringstream linestream(line);  
    linestream>>jiffy_char;
    while(linestream>>jiffy_char){
      long value;
      std::istringstream(jiffy_char)>>value;
      a.push_back(value);
    }
  }
    for (long temp_jiffy:a){
      total_jiffy+=temp_jiffy;
    }
   active_jiffy= total_jiffy-a[3]-a[4];
   return active_jiffy;
   
 }
 


// TODO: Read and return the number of idle jiffies for the system
long LinuxParser::IdleJiffies() {
  string line ;
  vector<long> a{};
  long idle_jiffy;
  
  std::ifstream stream(kProcDirectory + kStatFilename);
  if(stream.is_open()){
    while(getline(stream,line)){
     long tag_jiffy ;
     std::istringstream linestream(line);
     while(linestream>>tag_jiffy){
      a.emplace_back(tag_jiffy);
     }
    }
  }
   idle_jiffy=a[3]+a[4];
  return idle_jiffy;
 } 
  


// TODO: Read and return CPU utilization
vector<string> LinuxParser::CpuUtilization() {
  string line ;
  vector<string> a{};
  std::ifstream stream(kProcDirectory + kStatFilename);
  if(stream.is_open()){
    while(getline(stream,line)){
     string tag_cpu;
     std::istringstream linestream(line);
     linestream>>tag_cpu;
     a.emplace_back(tag_cpu);
    }

  }
  return a;
 }

 

// TODO: Read and return the total number of processes
//**
int LinuxParser::TotalProcesses() {
  string processes;
  int value;
  string line;
  std::ifstream stream(kProcDirectory + kStatFilename);
  if (stream.is_open()) {
    while(std::getline(stream, line)){
      std::istringstream linestream(line);
      while(linestream >> processes >>value){
        if(processes=="processes") {return value;};
      }
   }
 }return value;
}
// TODO: Read and return the number of running processes
//**
int LinuxParser::RunningProcesses() {
  string procs_running;
  int value;
  string line;
  std::ifstream stream(kProcDirectory + kStatFilename);
  if (stream.is_open()) {
    while(std::getline(stream, line)){
      std::istringstream linestream(line);
      while(linestream >> procs_running >>value){
        if(procs_running=="procs_running") {return value;};
      }
   }
 }return value; }

// TODO: Read and return the command associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Command(int pid) { 
  string line;
  std::ifstream stream(kProcDirectory + "/"+to_string(pid)+kCmdlineFilename);
  if(stream.is_open()){
   std::getline(stream,line);
    
  } return line; }

// TODO: Read and return the memory used by a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Ram(int pid) { 
  string line,ram_value;
  std::ifstream stream(kProcDirectory + "/"+to_string(pid)+kStatusFilename);
  if(stream.is_open()){
   while(getline(stream,line)){
     std::replace(line.begin(),line.end(),':',' ');
     string ram;
     long value;
     std::istringstream linestream(line);
     linestream>>ram>>value;
     if(ram=="Vmsize"){
     ram_value=to_string(value);
     break;
     }
   }
}
 return ram_value+"MB";
}
// TODO: Read and return the user ID associated with a process
// REMOVE: [[maybe_unused]] once you define the function
//string LinuxParser::Uid(int p){
//return string(); }


// TODO: Read and return the user associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::User(int pid) {
  string line,user_value;
  std::ifstream stream(kProcDirectory + "/"+to_string(pid)+kStatusFilename);
  if(stream.is_open()){
   while(getline(stream,line)){
     std::replace(line.begin(),line.end(),':',' ');
     string user;
     long value;
     std::istringstream linestream(line);
     linestream>>user>>value;
     if(user=="Uid"){
     user_value=to_string(value);
     break;
     }
   }
}
 return user_value;
  

 }

// TODO: Read and return the uptime of a process
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::UpTime(int pid) { 
  string line;
  int j=1;
  long process_time;
  std::ifstream stream(kProcDirectory + "/"+to_string(pid)+kStatFilename);
  if(stream.is_open()){
   while(getline(stream,line)){
     
     char c;
     long value;
     std::istringstream linestream(line);
     while(linestream>>c || linestream>>value){
       if (j==1){
         process_time=value;
         
       }
       j+=1;
       }
   
     }
   }
   return  process_time ;
}
